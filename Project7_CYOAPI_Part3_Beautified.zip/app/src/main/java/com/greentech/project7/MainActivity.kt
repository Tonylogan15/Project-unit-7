package com.greentech.project7

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.greentech.project7.adapter.ProjectAdapter
import com.greentech.project7.databinding.ActivityMainBinding
import com.greentech.project7.model.ProjectItem

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Sample data (shows at least two pieces of data per item: icon + title + subtitle)
        val items = listOf(
            ProjectItem("Solar Optimizer", "AI-tuned panels increase yield by 12%"),
            ProjectItem("Smart Irrigation", "Soil sensors cut water use by 30%"),
            ProjectItem("Waste Tracker", "Turns waste streams into revenue"),
            ProjectItem("Wind Analytics", "Predictive maintenance for turbines"),
            ProjectItem("EV Routing", "Optimized routes for lower grid impact")
        )

        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = ProjectAdapter(items)
            setHasFixedSize(true)
        }
    }
}
