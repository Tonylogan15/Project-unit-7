package com.greentech.project7.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.greentech.project7.R
import com.greentech.project7.databinding.ItemProjectBinding
import com.greentech.project7.model.ProjectItem

class ProjectAdapter(private val data: List<ProjectItem>) :
    RecyclerView.Adapter<ProjectAdapter.VH>() {

    inner class VH(val binding: ItemProjectBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemProjectBinding.inflate(inflater, parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = data[position]
        holder.binding.title.text = item.title
        holder.binding.subtitle.text = item.subtitle
        holder.binding.icon.setImageResource(R.drawable.ic_leaf)
    }

    override fun getItemCount(): Int = data.size
}
