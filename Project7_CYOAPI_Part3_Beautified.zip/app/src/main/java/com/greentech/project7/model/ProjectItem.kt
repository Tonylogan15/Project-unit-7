package com.greentech.project7.model

data class ProjectItem(
    val title: String,
    val subtitle: String
)
