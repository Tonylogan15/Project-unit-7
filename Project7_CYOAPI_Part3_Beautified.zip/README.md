# Project 7 - CYOAPI Part 3: ✨ Beautified ✨

This app demonstrates:
- ✅ RecyclerView with a scrollable list
- ✅ Each item shows at least two data points (icon + title + subtitle)
- ✅ Downloadable font (Roboto Slab) via Fonts-in-XML
- ✅ Custom theme (`Theme.GreenTech`) in `themes.xml` (light + dark)
- ✅ Additional styles in `styles.xml` (e.g., `Text.Title`, `Text.Body`, `Text.Headline`, `Card.Rounded`)

## Walkthrough (Video/GIF)
_Add your Loom link or GIF here._

## Required Features Checklist
- [x] App contains a RecyclerView that displays a list of scrollable data
- [x] App displays at least two pieces of data for each item
- [x] Uses a **downloadable font** with custom color and size
- [x] Modifies the **theme** of the app in `themes.xml`
- [x] Defines and applies styles in `themes.xml` and `styles.xml`

## How to Run
1. Open this folder in **Android Studio**.
2. Let Gradle sync.
3. Build & run on an emulator or device (API 24+).

> Note: Downloadable Fonts require Google Play services on the device/emulator. If you prefer a bundled font, drop a `.ttf` in `res/font` and change `@font/roboto_slab` to that file.

## Attribution
- Font: **Roboto Slab** (Google Fonts via Downloadable Fonts API)
