package com.example.randomlist.model

data class Creature(
    val name: String,
    val species: String,
    val funFact: String
)
