package com.example.randomlist

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.randomlist.databinding.ActivityMainBinding
import com.example.randomlist.model.Creature
import com.example.randomlist.ui.CreatureAdapter

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val creatures = listOf(
            Creature("Nova", "Star Fox", "Can see perfectly in the dark."),
            Creature("Pebble", "Rock Turtle", "Collects shiny stones for a cozy cave."),
            Creature("Puff", "Cloud Dragon", "Changes color with the weather."),
            Creature("Byte", "Robo Ferret", "Eats loose screws and forgotten USB drives."),
            Creature("Sprout", "Moss Deer", "Grows flowers when it hears music."),
            Creature("Ember", "Tiny Phoenix", "Reignites every sunrise."),
            Creature("Ripple", "Pond Spirit", "Creates tiny waves when it laughs.")
        )

        val adapter = CreatureAdapter(creatures)

        binding.rvRandom.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            this.adapter = adapter
        }
    }
}
