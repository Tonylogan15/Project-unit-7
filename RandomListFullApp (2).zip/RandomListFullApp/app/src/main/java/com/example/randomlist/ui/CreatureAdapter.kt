package com.example.randomlist.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.randomlist.databinding.ItemCreatureBinding
import com.example.randomlist.model.Creature

class CreatureAdapter(
    private val creatures: List<Creature>
) : RecyclerView.Adapter<CreatureAdapter.CreatureViewHolder>() {

    inner class CreatureViewHolder(
        private val binding: ItemCreatureBinding
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind(creature: Creature) {
            binding.creatureName.text = creature.name
            binding.creatureSpecies.text = creature.species
            binding.creatureFact.text = creature.funFact
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CreatureViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemCreatureBinding.inflate(inflater, parent, false)
        return CreatureViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CreatureViewHolder, position: Int) {
        holder.bind(creatures[position])
    }

    override fun getItemCount(): Int = creatures.size
}
